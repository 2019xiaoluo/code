create definer = root@localhost trigger tf_insert
    after insert
    on student
    for each row
begin
        replace into accountnum values(new.sno,'123456','0');
        replace into reward values(new.sno,'#','#',0);
    end;

