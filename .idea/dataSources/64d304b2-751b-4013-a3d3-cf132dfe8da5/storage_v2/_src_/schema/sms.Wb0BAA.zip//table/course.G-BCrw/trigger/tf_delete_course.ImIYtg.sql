create definer = root@localhost trigger tf_delete_course
    after delete
    on course
    for each row
begin
        delete from scj where cno=old.cno;
    end;

