create definer = root@localhost trigger tf_delete
    after delete
    on student
    for each row
begin
        delete  from scj where scj.sno=old.sno;
        delete  from accountnum where accountnum.id=old.sno;
        delete from reward where reward.sno=old.sno;
    end;

