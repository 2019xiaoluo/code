create definer = root@localhost trigger tf_insert_scj
    after insert
    on scj
    for each row
begin
        update reward set altercourse=concat(altercourse,concat('#',new.cno)) ,
        gerencredit=gerencredit+(select credit from course where cno=new.cno) 
        where sno=new.sno;
    end;

